# My Daily Progress — Android Studio project

An offline-first personal checklist app with:
- Reusable fixed daily tasks plus one-off tasks
- Completion percentage and points out of 100
- Daily, weekly and monthly history
- Consecutive-day streak
- Local browser storage inside Android WebView; no account or internet required

## Build an installable APK
1. Install Android Studio on a computer.
2. Open this `MyDailyProgress` folder as a project.
3. Let Android Studio sync Gradle (the first build needs internet to download Android Gradle Plugin and SDK components).
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

The app itself does not request internet permission and its saved data remains on this phone. Clearing app storage or uninstalling the app can erase local records, so consider exporting/backing up data in a future version.
